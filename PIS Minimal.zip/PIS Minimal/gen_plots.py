#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Tested with:
# Python 2.7.5
# Numpy 1.7.1
# Gnuplot 5.2 patchlevel 4

import csv
import math
import numpy
import os
import subprocess
import sys
from collections import Counter

# Configuration.
nr_of_supported_models = 202
experiments = [
    # CSV file basename                                 Algorithm name for plot                        Plot style nr     Reference model used
    # WP NOP (baseline)
    ('HADS_PIS_MINIMAL_seed1',                							'HADS_PIS_MINIMAL_seed 1',                                  		1,                 False),
    ('HADS_PIS_MINIMAL_seed2',                							'HADS_PIS_MINIMAL_seed 2',                                  		2,                 False),
	('HADS_PIS_MINIMAL_seed3',                							'HADS_PIS_MINIMAL_seed 3',                                  		3,                 False),
    ('HADS_PIS_MINIMAL_seed4',                							'HADS_PIS_MINIMAL_seed 4',                                  		4,                 False),
    ('HADS_PIS_MINIMAL_seed5',                							'HADS_PIS_MINIMAL_seed 5',                                  		5,                 False),
    ('HADS_PIS_MINIMAL_seed6',                							'HADS_PIS_MINIMAL_seed 6',                                  		6,                 False),
    ('HADS_PIS_MINIMAL_seed7',                							'HADS_PIS_MINIMAL_seed 7',                                  		7,                 False),
    ('HADS_PIS_MINIMAL_seed8',                							'HADS_PIS_MINIMAL_seed 8',                                  		8,                 False),
    ('HADS_PIS_MINIMAL_seed9',                							'HADS_PIS_MINIMAL_seed 9',                                  		9,                 False),
	('HADS_PIS_MINIMAL_seed10',                							'HADS_PIS_MINIMAL_seed 10',                                  		10,                 False),
    ('HADS_PIS_MINIMAL_seed11',                							'HADS_PIS_MINIMAL_seed 11',                                  	    11,                False),
	('HADS_PIS_MINIMAL_seed12',                							'HADS_PIS_MINIMAL_seed 12',                                  		12,                False),
    ('HADS_PIS_MINIMAL_seed13',                							'HADS_PIS_MINIMAL_seed 13',                                  		13,                False),
	('HADS_PIS_MINIMAL_seed14',                							'HADS_PIS_MINIMAL_seed 14',                                  		14,                False),
    ('HADS_PIS_MINIMAL_seed15',                							'HADS_PIS_MINIMAL_seed 15',                                  		15,                False),
    ('HADS_PIS_MINIMAL_seed16',                							'HADS_PIS_MINIMAL_seed 16',                                  		16,                False),
    ('HADS_PIS_MINIMAL_seed17',                							'HADS_PIS_MINIMAL_seed 17',                                  		17,                False),
    ('HADS_PIS_MINIMAL_seed18',                							'HADS_PIS_MINIMAL_seed 18',                                  		18,                False),
    ('HADS_PIS_MINIMAL_seed19',                							'HADS_PIS_MINIMAL_seed 19',                                  		19,                False),
	('HADS_PIS_MINIMAL_seed20',                							'HADS_PIS_MINIMAL_seed 20',                                  		20,                 False),
    ('HADS_PIS_MINIMAL_seed21',                							'HADS_PIS_MINIMAL_seed 21',                                  		21,                False),
    ('HADS_PIS_MINIMAL_seed22',                							'HADS_PIS_MINIMAL_seed 22',                                  	    22,                False),
	('HADS_PIS_MINIMAL_seed23',                							'HADS_PIS_MINIMAL_seed 23',                                  		23,                False),
    ('HADS_PIS_MINIMAL_seed24',                							'HADS_PIS_MINIMAL_seed 24',                                  		24,                False),
	('HADS_PIS_MINIMAL_seed25',                							'HADS_PIS_MINIMAL_seed 25',                                  		25,                False),
    ('HADS_PIS_MINIMAL_seed26',                							'HADS_PIS_MINIMAL_seed 26',                                  		26,                False),
    ('HADS_PIS_MINIMAL_seed27',                							'HADS_PIS_MINIMAL_seed 27',                                  		27,                False),
    ('HADS_PIS_MINIMAL_seed28',                							'HADS_PIS_MINIMAL_seed 28',                                  		28,                False),
    ('HADS_PIS_MINIMAL_seed29',                							'HADS_PIS_MINIMAL_seed 29',                                  		29,                False),
    ('HADS_PIS_MINIMAL_seed30',                							'HADS_PIS_MINIMAL_seed 30',                                  		30,                False),
	('any_configuration',                           					'Best configuration per component',             					31,                False)
]

#assert sum([(1 if is_ref_model else 0) for filename_base, title, plot_style_nr, is_ref_model in experiments]) == 1

# C198itelist.
C198itelist = {
}

# Adapt list.
adapt_list = {
}

# Read CSV lines.
print 'Reading CSV files...'
csvs_lines = []
for filename in os.listdir('.'):
    if filename.endswith('.csv') and not filename == 'upset_plot.csv':
        with open(filename, 'r') as file:
            lines = [line for line in csv.reader(file, delimiter=';')]
        csvs_lines.append( (filename, lines) )

print 'Read {} CSV files.'.format(len(csvs_lines))

# Sanity check on headers.
print 'Checking header sanity...'
for filename, csv_lines in csvs_lines:
    headers = csv_lines[0]
    assert headers[0] == 'name' # First header column must be 'name' of the model/sub-component
    assert 'filename' not in headers # No 'filename' header column yet
    assert len(headers) == len(set(headers)) # Check no duplicate header column names
    remaining_lines = csv_lines[1:]
    for line in remaining_lines:
        assert len(line) == len(headers) # Check same number of cells for header and other lines

# Convert to dict records.
print 'Converting lines to records...'
csvs_records = []
for filename, csv_lines in csvs_lines:
    headers = csv_lines[0]
    remaining_lines = csv_lines[1:]
    records = [dict(zip(headers, line)) for line in remaining_lines]
    records = [r for r in records if r['name'] != 'name'] # Get rid of repeated headers in case of merging multiple CSVs
    for r in records:
        r['filename'] = filename
    csvs_records.append( records )

# Check no duplicate names. Based on model/sub-component name.
print 'Checking for duplicate entries...'
for records in csvs_records:
    name_counter = Counter([r['name'] for r in records])
    duplicate_names = [(n,c) for n,c in name_counter.iteritems() if c > 1]
    assert len(duplicate_names) == 0, 'Duplicate entries for some names: {}'.format(duplicate_names)

# Check for same entries in all CSV files.
print 'Checking for same entries in all CSV files...'
last_names = None
for records in csvs_records:
    cur_names = set([r['name'] for r in records])
    if last_names is not None:
        assert last_names == cur_names # Check for same entries in CSV files.
    last_names = cur_names

# Check all finished without errors.
print 'Checking that no skipped/failed experiments...'
for records in csvs_records:
    for r in records:
        assert r['skipped'] == 'not_skipped' # Check that no entries skipped.
        # Check that finished without errors.
        if r['exception'] != '':
            # Check against C198itelist. Manually checked that OK for this purpose.
            C198itelist_cmp_rslt = C198itelist.get( (r['filename'], r['name']) )
            if C198itelist_cmp_rslt is not None:
                print 'C198itelist: filename={0}, model/name={1}, cmp_rslt={2}'.format(r['filename'], r['name'], C198itelist_cmp_rslt)
                assert C198itelist_cmp_rslt == r['compareResult'], 'Error during experiment, actual compare result = {0}, C198itelist compare result = {1}'.format(C198itelist_cmp_rslt, r['compareResult'])
                continue

            # Check against adapt list.
            adapt_list_rslt = adapt_list.get( (r['filename'], r['name']) )
            if adapt_list_rslt is not None:
                print 'Adapted: filename={0}, model/name={1}, cmp_rslt={2}'.format(r['filename'], r['name'], adapt_list_rslt)
                r['compareResult'] = adapt_list_rslt
                continue

            # Error, but not in C198itelist or adapt list.
            assert False, 'Error during experiment, not in C198itelist/adaptlist: filename={0}, model/name={1}'.format(r['filename'], r['name'])



# Get data for number of models learned plot.
print 'Generating data: plot_learned_models_*...'
def get_total_active_learning_time(r):
    learn_time = int(r['durationMsLearningLearn'])
    test_time = int(r['durationMsLearningTest'])
    assert learn_time >= 0, 'filename={}, name={}, learn_time={}'.format(r['filename'], r['name'], learn_time)
    assert test_time >= 0, 'filename={}, name={}, test_time={}'.format(r['filename'], r['name'], test_time)
    return learn_time + test_time

def compare_total_active_learning_time(r1, r2):
    time1 = get_total_active_learning_time(r1)
    time2 = get_total_active_learning_time(r2)
    if time1 < time2:
        return -1
    elif time1 == time2:
        return 0
    else:
        return 1

def ms_to_min(t):
    return t*1.0/1000/60

def ms_to_s(t):
    return t*1.0/1000

def min_to_ms(t):
    return t*1.0*1000*60

plot_series = []
for records in csvs_records:
    learned_records = [r for r in records if r['compareResult'] == 'SAME']
    sorted_records = sorted(learned_records, compare_total_active_learning_time)
    plot_serie = [(0, 0)]
    count = 0
    for r in sorted_records:
        plot_serie.append( (get_total_active_learning_time(r), count) )
        count += 1
        plot_serie.append( (get_total_active_learning_time(r), count) )
    highest_time = ms_to_min(get_total_active_learning_time(sorted_records[-1]))
    if highest_time < 60:
        plot_serie.append( (min_to_ms(60), count) )
    plot_series.append( (r['filename'], plot_serie) )

# Add serie for union of all configurations, excluding ref model (learned using 'any' configuration).
def is_ref_model_file(filename):
    for filename_base, title, plot_style_nr, is_ref_model in experiments:
        if filename == filename_base + '.csv':
            return is_ref_model
    assert False, 'Failed to determine C198ether experiment concerns ref model, for: {0}'.format(filename)

best_times_per_model = dict()
for records in csvs_records:
    learned_records = [r for r in records if r['compareResult'] == 'SAME']
    for r in learned_records:
        if is_ref_model_file(r['filename']):
            continue
        t = get_total_active_learning_time(r)
        if r['name'] not in best_times_per_model:
            best_times_per_model[r['name']] = sys.maxsize
        best_times_per_model[r['name']] = min(best_times_per_model[r['name']], t)
best_times = sorted(best_times_per_model.values())
best_plot_serie = [(0, 0)]
best_count = 0
for t in best_times:
    best_plot_serie.append( (t, best_count) )
    best_count += 1
    best_plot_serie.append( (t, best_count) )
best_highest_time = ms_to_min(best_times[-1])
if best_highest_time < 60:
    best_plot_serie.append( (min_to_ms(60), best_count) )
plot_series.append( ('any_configuration.csv', best_plot_serie) )

#Reorder plot series.
def cmp_plot_series(s1, s2):
    name1, serie1 = s1
    name2, serie2 = s2
    idx1 = None
    idx2 = None
    for i in xrange(len(experiments)):
        if experiments[i][0] + '.csv' == name1:
            idx1 = i
        if experiments[i][0] + '.csv' == name2:
            idx2 = i
    assert idx1 is not None, 'No experiment found for: {0}'.format(name1)
    assert idx2 is not None, 'No experiment found for: {0}'.format(name2)
    return cmp(idx1, idx2)

plot_series = sorted(plot_series, cmp_plot_series)

# Generate learned models plot.
def get_title(filename):
    for filename_base, title, plot_style_nr, is_ref_model in experiments:
        if filename == filename_base + '.csv':
            return title
    assert False, 'No title for: {0}'.format(filename)

def get_plot_style_nr(filename):
    for filename_base, title, plot_style_nr, is_ref_model in experiments:
        if filename == filename_base + '.csv':
            return plot_style_nr
    assert False, 'No plot style nr for: {0}'.format(filename)

largest_plot_style_nr = max([s for f,t,s,r in experiments])
for max_plot_style_nr in xrange(1,largest_plot_style_nr+1):
    plot_filename_base = 'plot_learned_models_up_to_category_' + str(max_plot_style_nr)
    print 'Generating plot: {0}...'.format(plot_filename_base)
    plot_series_for_plot = [(filename, plot_serie) for (filename, plot_serie) in plot_series if get_plot_style_nr(filename) <= max_plot_style_nr]
    with open(plot_filename_base + '.plt', 'w') as file:
        file.write('set terminal png size 800,600\n')
        file.write('set output "{0}.png"\n'.format(plot_filename_base))
        file.write('\n')
        file.write('set xlabel "Active learning timeout (learning+testing), per component [min]"\n')
        file.write('set ylabel "Number of components learned"\n')
        file.write('set ytics add ("{0}" {0})\n'.format(nr_of_supported_models)) # Indicate total number of supported components (the total)
        file.write('set ytics add ("{0}" {0})\n'.format(len(best_times_per_model), len(best_times_per_model))) # Indicate combined max models learned
        #file.write('set label "{0}" at 60.25, {0}\n'.format(len(best_times_per_model), len(best_times_per_model)))
        file.write('set key inside bottom right maxrows 14 font ",9"\n')
        file.write('\n')
        file.write('set style line 1  linecolor rgb \'#a6cee3\' linetype 1 linewidth 2\n')
        file.write('set style line 2  linecolor rgb \'#95bdd2\' linetype 1 linewidth 2\n')
        file.write('set style line 3  linecolor rgb \'#1f78b4\' linetype 1 linewidth 2\n')
        file.write('set style line 4  linecolor rgb \'#b2df8a\' linetype 1 linewidth 2\n')
        file.write('set style line 5  linecolor rgb \'#82cf70\' linetype 1 linewidth 2\n')
        file.write('set style line 6  linecolor rgb \'#33a02c\' linetype 1 linewidth 2\n')
        file.write('set style line 7  linecolor rgb \'#fb9a99\' linetype 1 linewidth 2\n')
        file.write('set style line 8  linecolor rgb \'#e31a1c\' linetype 1 linewidth 2\n')
        file.write('set style line 9  linecolor rgb \'#fdbf6f\' linetype 1 linewidth 2\n')
        file.write('set style line 10  linecolor rgb \'#ff7f00\' linetype 1 linewidth 2\n')
        file.write('set style line 11 linecolor rgb \'#cab2d6\' linetype 1 linewidth 2\n')
        file.write('set style line 12 linecolor rgb \'#6a3d9a\' linetype 1 linewidth 2\n')
        file.write('set style line 13 linecolor rgb \'#dddd99\' linetype 1 linewidth 2\n')
        file.write('set style line 14 linecolor rgb \'#b15928\' linetype 1 linewidth 2\n')
        file.write('set style line 15 linecolor rgb \'#cccccc\' linetype 1 linewidth 2\n')
        file.write('\n')
        file.write('set border 3 back lc rgb \'#000000\' lt 1\n')
        file.write('set border linewidth 1.5\n')
        file.write('\n')
        file.write('set grid back lc rgb \'#808080\' lt 0 lw 1\n')
        file.write('set grid back\n')
        file.write('\n')
        file.write('set yrange [-{0}*0.05:{0}*1.05]\n'.format(nr_of_supported_models))
        #file.write('set autoscale yfixmin\n')
        #file.write('set autoscale yfixmax\n')
        file.write('set autoscale xfixmin\n')
        file.write('set autoscale xfixmax\n')
        file.write('set offsets graph 0.05, graph 0.05, graph 0.05, graph 0.05\n')
        file.write('\n')

        file.write('plot \\\n')
        for idx, (filename, plot_serie) in enumerate(plot_series_for_plot):
            title = get_title(filename)
            plot_style_nr = get_plot_style_nr(filename)
            file.write('  \'-\' using 1:2 with lines title "{0}" ls {1}'.format(title, plot_style_nr))
            if idx < len(plot_series_for_plot) - 1:
                file.write(', \\\n')
            else:
                file.write('\n')
        for filename, plot_serie in plot_series_for_plot:
            for x, y in plot_serie:
                file.write('        {0} {1}\n'.format(ms_to_min(x), y))
            file.write('    EOF\n')

    subprocess.check_call(['gnuplot', plot_filename_base + '.plt'])

# Get data for inputs vs states plot.
print 'Generating data: plot_inputs_vs_states_any_config_*...'
all_names = set()
nr_states = dict()
nr_inputs = dict()
learned_names_any_config = set()
for records in csvs_records:
    if is_ref_model_file(records[0]['filename']):
        continue
    this_same = set()
    this_diff = set()
    for r in records:
        rslt = r['compareResult']
        if rslt == 'SAME':
            this_same.add(r['name'])
        elif rslt == 'DIFFERENT':
            this_diff.add(r['name'])
        if rslt in ('SAME', 'DIFFERENT'):
            this_states = int(r['nrExpectedMealyStates'])
            this_inputs = int(r['apiNrInputs'])
            if nr_states.get(r['name']) is None:
                nr_states[r['name']] = this_states
            assert nr_states[r['name']] == this_states
            if nr_inputs.get(r['name']) is None:
                nr_inputs[r['name']] = this_inputs
            assert nr_inputs[r['name']] == this_inputs
    assert len(this_same) + len(this_diff) == nr_of_supported_models, '#same+#diff != {0}, #same={1}, #diff={2}, filename={3}'.format(nr_of_supported_models, len(this_same), len(this_diff), r['filename'])
    all_names.update(this_same)
    all_names.update(this_diff)
    learned_names_any_config.update(this_same)
assert len(all_names) == nr_of_supported_models
assert len(nr_states) == nr_of_supported_models
assert len(nr_inputs) == nr_of_supported_models
assert set(nr_states.keys()) == all_names
assert set(nr_inputs.keys()) == all_names

max_nr_inputs = max(nr_inputs.values())
max_nr_states = max(nr_states.values())
x_max = 300 #int(10**math.ceil(math.log10(max_nr_inputs)))
y_max = int(10**math.ceil(math.log10(max_nr_states)))

# Generate inputs vs states plot (black/C198ite).
print 'Generating plot: plot_inputs_vs_states...'
with open('plot_inputs_vs_states.plt', 'w') as file:
    file.write('set terminal png size 640,480\n')
    file.write('set output "plot_inputs_vs_states.png"\n')
    file.write('\n')
    file.write('set xlabel "Number of inputs"\n')
    file.write('set ylabel "Number of Mealy machine states"\n')
    file.write('set key off\n')
    file.write('set xtics add ("{}" {})\n'.format(max_nr_inputs, max_nr_inputs))
    file.write('set ytics add ("{}" {})\n'.format(max_nr_states, max_nr_states))
    file.write('set xtics add ("{}" {})\n'.format(x_max, x_max))
    file.write('set ytics add ("{}" {})\n'.format(y_max, y_max))
    file.write('\n')
    file.write('set style line 11 lc rgb \'#000000\' lt 1\n')
    file.write('set border 3 back ls 11\n')
    file.write('set border linewidth 1.5\n')
    file.write('\n')
    file.write('set style line 12 lc rgb \'#808080\' lt 0 lw 1\n')
    file.write('set grid back ls 12\n')
    file.write('set grid back\n')
    file.write('\n')
    file.write('set autoscale yfixmin\n')
    file.write('set autoscale yfixmax\n')
    file.write('set autoscale xfixmin\n')
    file.write('set autoscale xfixmax\n')
    file.write('set offsets graph 0.05, graph 0.05, graph 0.05, graph 0.05\n')
    file.write('\n')
    file.write('set xrange [1:{}]\n'.format(x_max))
    file.write('set yrange [1:{}]\n'.format(y_max))
    file.write('set logscale x 10\n')
    file.write('set logscale y 10\n')
    file.write('plot \'-\' using 1:2 ls 11 notitle\n');
    for name in sorted(all_names):
        file.write('    {0} {1}\n'.format(nr_inputs[name], nr_states[name]));
    file.write('EOF\n');

subprocess.check_call(['gnuplot', 'plot_inputs_vs_states.plt'])

# Generate inputs vs states plot with red/green for learned status.
for with_oce in (True, False):
    filename_base = 'plot_inputs_vs_states_any_config'
    filename_base += '_with_oce' if with_oce else ''
    print 'Generating plot: {0}...'.format(filename_base)
    with open(filename_base + '.plt', 'w') as file:
        file.write('set terminal png size 640,480\n')
        file.write('set output "{0}.png"\n'.format(filename_base))
        file.write('\n')
        file.write('set xlabel "Number of inputs"\n')
        file.write('set ylabel "Number of Mealy machine states"\n')
        file.write('set key inside top left box\n')
        file.write('set xtics add ("{}" {})\n'.format(max_nr_inputs, max_nr_inputs))
        file.write('set ytics add ("{}" {})\n'.format(max_nr_states, max_nr_states))
        file.write('set xtics add ("{}" {})\n'.format(x_max, x_max))
        file.write('set ytics add ("{}" {})\n'.format(y_max, y_max))
        file.write('\n')
        file.write('set style line 1 linecolor rgb \'#32CD32\' linetype 1\n')
        file.write('set style line 7 linecolor rgb \'#FF4040\' linetype 1\n')
        file.write('\n')
        file.write('set style line 11 lc rgb \'#000000\' lt 1\n')
        file.write('set border 3 back ls 11\n')
        file.write('set border linewidth 1.5\n')
        file.write('\n')
        file.write('set style line 12 lc rgb \'#808080\' lt 0 lw 1\n')
        file.write('set grid back ls 12\n')
        file.write('set grid back\n')
        file.write('\n')
        file.write('set autoscale yfixmin\n')
        file.write('set autoscale yfixmax\n')
        file.write('set autoscale xfixmin\n')
        file.write('set autoscale xfixmax\n')
        file.write('set offsets graph 0.05, graph 0.05, graph 0.05, graph 0.05\n')
        file.write('\n')
        file.write('set xrange [1:{}]\n'.format(x_max))
        file.write('set yrange [1:{}]\n'.format(y_max))
        file.write('set logscale x 10\n')
        file.write('set logscale y 10\n')
        if with_oce:
            file.write('set label "Oc�" at 77-12, 3410+1750\n') #Oc�
        file.write('plot \\\n')
        if with_oce:
            file.write('  \'-\' using 1:2 notitle linecolor rgb \'#3232CD\' linetype 1 linewidth 3, \\\n') #Oc�
        file.write('  \'-\' using 1:2 ls 1 title \'Learned by at least one configuration\', \\\n');
        file.write('  \'-\' using 1:2 ls 7 title \'Not learned by any configuration\'\n');
        if with_oce:
            file.write('  77 3410\n') #Oc�
            file.write('EOF\n') #Oc�
        for name in sorted(learned_names_any_config):
            file.write('    {0} {1}\n'.format(nr_inputs[name], nr_states[name]));
        file.write('EOF\n');
        for name in sorted(all_names):
            if name not in learned_names_any_config:
                file.write('    {0} {1}\n'.format(nr_inputs[name], nr_states[name]));
        file.write('EOF\n');

    subprocess.check_call(['gnuplot', filename_base + '.plt'])

# UpSet plot data file.
# Use to generate UpSet plot: https://gehlenborglab.shinyapps.io/upsetr/
# Header: yes
# Separator: Semicolon
# Select specific sets: add all
# Limit number of intersections to: as high as possible, to show all (double check that nothing omitted)
# Order by: Degree
# Increasing/Decreasing: Decreasing
# Bar:Matrix ratio: 0.7
# Number angles: 0
# Show empry intersections: no
# Point size: 4
# File type: png
# Advanced / * Text Scale: 2
# Advanced / * Text Size: 2
# (Manually move 'Intersection Size' axis label closer to the axis in the generated PNG)
print 'Generating data: upset_plot...'
with open('upset_plot.csv', 'w') as file:
    upset_header = []
    for records in csvs_records:
        upset_filename = records[0]['filename']
        if is_ref_model_file(upset_filename):
            continue
        upset_title = get_title(upset_filename)
        upset_header.append(upset_title)
    file.write(';'.join(upset_header))
    file.write('\n')
    for name in all_names:
        first = True
        for records in csvs_records:
            upset_filename = records[0]['filename']
            if is_ref_model_file(upset_filename):
                continue
            value = None
            for record in records:
                if record['name'] == name:
                    if record['compareResult'] == 'SAME':
                        value = 1
                    elif record['compareResult'] == 'DIFFERENT':
                        value = 0
                    else:
                        assert False, record['compareResult']
            assert value is not None
            if not first:
                file.write(';')
            file.write(str(value))
            first = False
        file.write('\n')

# Inefficiency score plot.
print 'Generating plot: inefficiency_factor...'
inefficiency_factors = []
try:
    for name in all_names:
        min_time = 365 * 24 * 60 * 60 * 1000 #1 year in milliseconds
        max_time = 0
        min_config = None
        max_config = None
        min_model = None
        max_model = None
        conf_count = 0
        conf_learned = 0
        for records in csvs_records:
            upset_filename = records[0]['filename']
            if is_ref_model_file(upset_filename):
                continue
            for record in records:
                if record['name'] == name:
                    conf_count += 1
                    if record['compareResult'] == 'SAME':
                        conf_learned += 1
                    elif record['compareResult'] == 'DIFFERENT':
                        pass
                    else:
                        assert False, record['compareResult']
                    time = int(record['durationMsLearningLearn']) + int(record['durationMsLearningTest'])
                    if time < min_time:
                        min_time = time
                        min_config = get_title(upset_filename)
                        min_model = record['learnedResultUsedModel']
                    if time > max_time:
                        max_time = time
                        max_config = get_title(upset_filename)
                        max_model = record['learnedResultUsedModel']
        learned_by_all_configs = (conf_count == conf_learned)
        inefficiency_factor = max_time * 1.0 / min_time
        if conf_learned > 0:
            inefficiency_factors.append( (inefficiency_factor, min_time, max_time, learned_by_all_configs, name, min_config, max_config, min_model, max_model) )
finally:
    pass
inefficiency_factors = sorted(inefficiency_factors)
max_inefficiency_factor = max([x[0] for x in inefficiency_factors])
with open('inefficiency_factors.plt', 'w') as file:
    file.write('set terminal png size 1000,600\n')
    file.write('set output "inefficiency_factors.png"\n')
    file.write('\n')
    file.write('set xlabel "Model number (sorted on inefficiency factor)"\n')
    file.write('set ylabel "Inefficiency factor (worst time / best time)"\n')
    file.write('set key inside top left box\n')
    file.write('\n')
    file.write('set xtics 40\n')
    file.write('set xtics add ("{}" {})\n'.format(len(inefficiency_factors), len(inefficiency_factors)))
    file.write('set ytics add ("{}" {})\n'.format(round(max_inefficiency_factor,2), max_inefficiency_factor))
    file.write('set ylabel offset 2\n')
    file.write('\n')
    file.write('set style line 1 lc rgb \'#33a02c\' linetype 1 linewidth 2\n')
    file.write('set style line 2 lc rgb \'#1f78b4\' linetype 1 linewidth 2\n')
    file.write('\n')
    file.write('set style line 11 lc rgb \'#000000\' lt 1\n')
    file.write('set border 3 back ls 11\n')
    file.write('set border linewidth 1.5\n')
    file.write('\n')
    file.write('set style line 12 lc rgb \'#808080\' lt 0 lw 1\n')
    file.write('set grid back ls 12\n')
    file.write('set grid back\n')
    file.write('\n')
    file.write('set autoscale yfixmin\n')
    file.write('set autoscale yfixmax\n')
    file.write('set autoscale xfixmin\n')
    file.write('set autoscale xfixmax\n')
    file.write('set offsets graph 0.05, graph 0.05, graph 0.05, graph 0.05\n')
    file.write('set logscale y 10\n')
    file.write('\n')
    file.write('set boxwidth 0.4\n')
    file.write('set style fill solid\n')
    file.write('\n')
    file.write('plot \'-\' using 1:2 with boxes ls 1 title "Learned by all configurations", \\\n');
    file.write('     \'-\' using 1:2 with boxes ls 2 title "Learned by at least one configuration"\n');
    for idx, (inefficiency_factor, min_time, max_time, learned_by_all_configs, name, min_config, max_config, min_model, max_model) in enumerate(inefficiency_factors):
        if learned_by_all_configs:
            file.write('        # {0} min={1}="{2}" min_model={3} max={4}="{5}" max_model={6} \n'.format(name, min_time, min_config, min_model, max_time, max_config, max_model))
            file.write('        {0} {1}\n'.format(idx + 1, inefficiency_factor))
    file.write('EOF\n');
    for idx, (inefficiency_factor, min_time, max_time, learned_by_all_configs, name, min_config, max_config, min_model, max_model) in enumerate(inefficiency_factors):
        if not learned_by_all_configs:
            file.write('        # {0} min={1}="{2}" min_model={3} max={4}="{5}" max_model={6} \n'.format(name, min_time, min_config, min_model, max_time, max_config, max_model))
            file.write('        {0} {1}\n'.format(idx + 1, inefficiency_factor))
    file.write('EOF\n');

subprocess.check_call(['gnuplot', 'inefficiency_factors.plt'])

# Best/worst absolute time diff plot.
print 'Generating plot: best_worst_absolute_time_diff...'
best_worst_absolute_time_diff = [
    (max_time-min_time,min_time,max_time,learned_by_all_configs,name,min_config,max_config,min_model,max_model)
    for inefficiency_factor,min_time,max_time,learned_by_all_configs,name,min_config,max_config,min_model,max_model
    in inefficiency_factors
]
best_worst_absolute_time_diff = sorted(best_worst_absolute_time_diff)
max_best_worst_absolute_time_diff = max([x[0] for x in inefficiency_factors])
with open('best_worst_absolute_time_diff.plt', 'w') as file:
    file.write('set terminal png size 1000,600\n')
    file.write('set output "best_worst_absolute_time_diff.png"\n')
    file.write('\n')
    file.write('set xlabel "Model number (sorted on time difference)"\n')
    file.write('set ylabel "Time difference (worst time - best time) [min]"\n')
    file.write('set key inside top left box\n')
    file.write('\n')
    file.write('set xtics 40\n')
    file.write('set xtics add ("{}" {})\n'.format(len(best_worst_absolute_time_diff), len(best_worst_absolute_time_diff)))
    file.write('set ytics add ("{}" {})\n'.format(round(max_best_worst_absolute_time_diff,2), max_best_worst_absolute_time_diff))
    #file.write('set ylabel offset 2\n')
    file.write('\n')
    file.write('set style line 1 lc rgb \'#33a02c\' linetype 1 linewidth 2\n')
    file.write('set style line 2 lc rgb \'#1f78b4\' linetype 1 linewidth 2\n')
    file.write('\n')
    file.write('set style line 11 lc rgb \'#000000\' lt 1\n')
    file.write('set border 3 back ls 11\n')
    file.write('set border linewidth 1.5\n')
    file.write('\n')
    file.write('set style line 12 lc rgb \'#808080\' lt 0 lw 1\n')
    file.write('set grid back ls 12\n')
    file.write('set grid back\n')
    file.write('\n')
    file.write('set autoscale yfixmin\n')
    file.write('set autoscale yfixmax\n')
    file.write('set autoscale xfixmin\n')
    file.write('set autoscale xfixmax\n')
    file.write('set offsets graph 0.05, graph 0.05, graph 0.05, graph 0.05\n')
    #file.write('set logscale y 10\n')
    file.write('\n')
    file.write('set boxwidth 0.4\n')
    file.write('set style fill solid\n')
    file.write('\n')
    file.write('plot \'-\' using 1:2 with boxes ls 1 title "Learned by all configurations", \\\n');
    file.write('     \'-\' using 1:2 with boxes ls 2 title "Learned by at least one configuration"\n');
    for idx, (time_diff_ms, min_time, max_time, learned_by_all_configs, name, min_config, max_config, min_model, max_model) in enumerate(best_worst_absolute_time_diff):
        if learned_by_all_configs:
            file.write('        # {0} min={1}="{2}" min_model={3} max={4}="{5}" max_model={6} \n'.format(name, min_time, min_config, min_model, max_time, max_config, max_model))
            file.write('        {0} {1}\n'.format(idx + 1, ms_to_min(time_diff_ms)))
    file.write('EOF\n');
    for idx, (time_diff_ms, min_time, max_time, learned_by_all_configs, name, min_config, max_config, min_model, max_model) in enumerate(best_worst_absolute_time_diff):
        if not learned_by_all_configs:
            file.write('        # {0} min={1}="{2}" min_model={3} max={4}="{5}" max_model={6} \n'.format(name, min_time, min_config, min_model, max_time, max_config, max_model))
            file.write('        {0} {1}\n'.format(idx + 1, ms_to_min(time_diff_ms)))
    file.write('EOF\n');

subprocess.check_call(['gnuplot', 'best_worst_absolute_time_diff.plt'])

# # Get data for reference model run.
# print 'Generating data: plot_ref_*...'
# ref_model_records = []
# for records in csvs_records:
    # for r in records:
        # if not is_ref_model_file(r['filename']):
            # continue
        # ref_model_records.append(r)
# assert len(ref_model_records) == 287
# ref_model_records = [r for r in ref_model_records if r['compareResult'] == 'SAME']
# assert len(ref_model_records) == nr_of_supported_models

# # Reference model oracle: learn time as percentage of total AL time, per comp, sorted on percentage
# print 'Generating plot: plot_ref_learn_vs_test_percentage...'
# ref_learn_vs_test_values = []
# for r in ref_model_records:
    # ref_learn_vs_test_values.append(int(r['durationMsLearningLearn']) * 1.0 / (int(r['durationMsLearningLearn'])+int(r['durationMsLearningTest'])) * 100)
# ref_learn_vs_test_values = sorted(ref_learn_vs_test_values)
# with open('plot_ref_learn_vs_test_percentage.plt', 'w') as file:
    # file.write('set terminal png size 1280,600\n')
    # file.write('set output "plot_ref_learn_vs_test_percentage.png"\n')
    # file.write('\n')
    # file.write('set xlabel "Model number (sorted on percentages)"\n')
    # file.write('set ylabel "Learning time as percentage of learning + testing time"\n')
    # file.write('set key off\n')
    # file.write('\n')
    # file.write('set style line 11 lc rgb \'#000000\' lt 1\n')
    # file.write('set border 3 back ls 11\n')
    # file.write('set border linewidth 1.5\n')
    # file.write('\n')
    # file.write('set style line 12 lc rgb \'#808080\' lt 0 lw 1\n')
    # file.write('set grid back ls 12\n')
    # file.write('set grid back\n')
    # file.write('\n')
    # file.write('set autoscale yfixmin\n')
    # file.write('set autoscale yfixmax\n')
    # file.write('set autoscale xfixmin\n')
    # file.write('set autoscale xfixmax\n')
    # file.write('set offsets graph 0.05, graph 0.05, graph 0.05, graph 0.05\n')
    # file.write('\n')
    # file.write('plot \'-\' using 1:2 ls 1 notitle\n');
    # for idx, value in enumerate(ref_learn_vs_test_values):
        # file.write('        {0} {1}\n'.format(idx + 1, value))
    # file.write('EOF\n');

# subprocess.check_call(['gnuplot', 'plot_ref_learn_vs_test_percentage.plt'])

# # Reference model oracle: number of states vs learn time as percentage of total AL time
# print 'Generating plot: plot_ref_learn_vs_test_percentage_vs_nr_of_states...'
# max_nr_states = max([int(r['nrExpectedMealyStates']) for r in ref_model_records])
# with open('plot_ref_learn_vs_test_percentage_vs_nr_of_states.plt', 'w') as file:
    # file.write('set terminal png size 900,500\n')
    # file.write('set output "plot_ref_learn_vs_test_percentage_vs_nr_of_states.png"\n')
    # file.write('\n')
    # file.write('set xlabel "Number of Mealy machine states"\n')
    # file.write('set ylabel "Learning time as percentage of learning + testing time"\n')
    # file.write('set xtics add ("{}" {})\n'.format(max_nr_states, max_nr_states))
    # file.write('set key off\n')
    # file.write('\n')
    # file.write('set style line 11 lc rgb \'#000000\' lt 1\n')
    # file.write('set border 3 back ls 11\n')
    # file.write('set border linewidth 1.5\n')
    # file.write('\n')
    # file.write('set style line 12 lc rgb \'#808080\' lt 0 lw 1\n')
    # file.write('set grid back ls 12\n')
    # file.write('set grid back\n')
    # file.write('\n')
    # file.write('set autoscale yfixmin\n')
    # file.write('set autoscale yfixmax\n')
    # file.write('set autoscale xfixmin\n')
    # file.write('set autoscale xfixmax\n')
    # file.write('set offsets graph 0.05, graph 0.05, graph 0.05, graph 0.05\n')
    # file.write('set logscale x 10\n')
    # file.write('\n')
    # file.write('plot \'-\' using 1:2 ls 1 notitle\n');
    # for r in ref_model_records:
        # nr_of_states = int(r['nrExpectedMealyStates'])
        # percentage = int(r['durationMsLearningLearn']) * 1.0 / (int(r['durationMsLearningLearn'])+int(r['durationMsLearningTest'])) * 100
        # file.write('        {0} {1}\n'.format(nr_of_states, percentage))
    # file.write('EOF\n');

# subprocess.check_call(['gnuplot', 'plot_ref_learn_vs_test_percentage_vs_nr_of_states.plt'])

# # Reference model C18_armor plots
# for r in ref_model_records:
    # if r['name'] == 'C18_armor':
        # for filename_base, col_name, col_title, data_conversion_func in [
                    # ('plot_ref_C18_armor_per_round_time_learn', 'learnTimePerRound', 'Learning time [s]', ms_to_s),
                    # ('plot_ref_C18_armor_per_round_time_test', 'testTimePerRound', 'Testing time [s]', ms_to_s),
                    # ('plot_ref_C18_armor_per_round_time_save', 'saveTimePerRound', 'Save time [s]', ms_to_s),
                    # ('plot_ref_C18_armor_per_round_nr_states_added', 'nrMealyStatesPerRound', 'Number of Mealy machine states added to hypothesis', None),
                    # ('plot_ref_C18_armor_per_round_nr_mqs', 'nrMemberShipQueriesPerRound', 'Number of membership queries', None),
                    # ('plot_ref_C18_armor_per_round_nr_mss', 'nrMemberShPISymbolsPerRound', 'Number of membership symbols', None),
                # ]:
            # print 'Generating plot: {0}...'.format(filename_base)
            # with open(filename_base + '.plt', 'w') as file:
                # file.write('set terminal png size 600,600\n')
                # file.write('set output "{0}.png"\n'.format(filename_base))
                # file.write('\n')
                # file.write('set xlabel "Round"\n')
                # file.write('set ylabel "{0}"\n'.format(col_title))
                # file.write('set key off\n')
                # file.write('\n')
                # file.write('set style line 11 lc rgb \'#000000\' lt 1\n')
                # file.write('set border 3 back ls 11\n')
                # file.write('set border linewidth 1.5\n')
                # file.write('\n')
                # file.write('set style line 12 lc rgb \'#808080\' lt 0 lw 1\n')
                # file.write('set grid back ls 12\n')
                # file.write('set grid back\n')
                # file.write('\n')
                # file.write('set autoscale yfixmin\n')
                # file.write('set autoscale yfixmax\n')
                # file.write('set autoscale xfixmin\n')
                # file.write('set autoscale xfixmax\n')
                # file.write('set offsets graph 0.05, graph 0.05, graph 0.05, graph 0.05\n')
                # file.write('\n')
                # file.write('plot \'-\' using 1:2 ls 1 title \'C18_armor\'\n');
                # data = r[col_name]
                # assert data.startswith('[')
                # assert data.endswith(']')
                # data = data[1:-1]
                # data = [int(v.strip()) for v in data.split(',')]
                # values = [v if data_conversion_func is None else data_conversion_func(v) for v in data]
                # for idx, value in enumerate(values):
                    # file.write('        {0} {1}\n'.format(idx + 1, value))
                # file.write('EOF\n');

            # subprocess.check_call(['gnuplot', filename_base + '.plt'])

# # Per round test time for large models, not learned with reference model as there the testing is faked.
# for records in csvs_records:
    # for r in records:
        # if r['compareResult'] == 'SAME' and int(r['nrExpectedMealyStates']) >= 400 and not is_ref_model_file(r['filename']):
            # data = r['testTimePerRound']
            # assert data.startswith('[')
            # assert data.endswith(']')
            # data = data[1:-1]
            # data = [int(v.strip()) for v in data.split(',')]
            # values = [ms_to_s(v) for v in data]

            # stat_avg = numpy.average(values)
            # stat_std = numpy.std(values)
            # stat_max = max(values)

            # values_normal = [(i,v) for i,v in enumerate(values) if v <= stat_avg+stat_std]
            # values_outliers = [(i,v) for i,v in enumerate(values) if v > stat_avg+stat_std]

            # total_normal = sum([v[1] for v in values_normal])
            # total_outliers = sum([v[1] for v in values_outliers])
            # total_total = total_normal + total_outliers
            # percentage_outliers = total_outliers * 100.0 / total_total

            # filename_base = 'plot_per_round_test_time__' + r['name'] + '__' + r['filename']
            # assert filename_base.endswith('.csv')
            # filename_base = filename_base[:-4]
            # print 'Generating plot: {0}...'.format(filename_base)
            # with open(filename_base + '.plt', 'w') as file:
                # file.write('set terminal png size 1280,600\n')
                # file.write('set output "{0}.png"\n'.format(filename_base))
                # file.write('\n')
                # file.write('set xlabel "Round"\n')
                # file.write('set ylabel "Testing time [s]"\n')
                # file.write('set key below right box\n')
                # file.write('\n')
                # file.write('set style line 1 linecolor rgb \'#00cc00\' linetype 1\n')
                # file.write('set style line 2 linecolor rgb \'#ff0000\' linetype 1\n')
                # file.write('set style line 3 linecolor rgb \'#4040cc\' linetype 1\n')
                # file.write('set style line 4 linecolor rgb \'#cc00cc\' linetype 1\n')
                # file.write('set style line 5 linecolor rgb \'#ccaa00\' linetype 3\n')
                # file.write('set style line 6 linecolor rgb \'#000000\' linetype 1\n')
                # file.write('\n')
                # file.write('set style line 11 lc rgb \'#000000\' lt 1\n')
                # file.write('set border 3 back ls 11\n')
                # file.write('set border linewidth 1.5\n')
                # file.write('\n')
                # file.write('set style line 12 lc rgb \'#808080\' lt 0 lw 1\n')
                # file.write('set grid back ls 12\n')
                # file.write('set grid back\n')
                # file.write('\n')
                # file.write('set autoscale yfixmin\n')
                # file.write('set autoscale yfixmax\n')
                # file.write('set autoscale xfixmin\n')
                # file.write('set autoscale xfixmax\n')
                # file.write('set offsets graph 0.05, graph 0.1, graph 0.05, graph 0.05\n')
                # file.write('\n')
                # file.write('set label gprintf("%.2f", {}) at {}, {} tc ls 3\n'.format(stat_avg, len(values) * 1.01, stat_avg));
                # file.write('set label gprintf("%.2f", {}) at {}, {} tc ls 4\n'.format(stat_avg + stat_std, len(values) * 1.01, stat_avg + stat_std));
                # file.write('set label gprintf("%.2f", {}) at {}, {} tc ls 5\n'.format(stat_max, len(values) * 1.01, stat_max));
                # file.write('set label gprintf("Sum normal: %.2f s", {}) at character 1, 4 tc ls 6\n'.format(total_normal));
                # file.write('set label gprintf("Sum outliers: %.2f s", {}) at character 1, 3 tc ls 6\n'.format(total_outliers));
                # file.write('set label gprintf("Sum all: %.2f s", {}) at character 1, 2 tc ls 6\n'.format(total_total));
                # file.write('set label gprintf("Outliers/all: %.2f %%", {}) at character 1, 1 tc ls 6\n'.format(percentage_outliers));
                # file.write('plot \\\n');
                # file.write('     {} ls 3 title \'Mean value\', \\\n'.format(stat_avg));
                # file.write('     {} ls 4 title \'Normal/outlier separation value (Mean+SD)\', \\\n'.format(stat_avg + stat_std));
                # file.write('     {} ls 5 dt 3 title \'Max value\', \\\n'.format(stat_max));
                # file.write('     \'-\' using 1:2 ls 1 title \'Normal values\', \\\n');
                # file.write('     \'-\' using 1:2 ls 2 title \'Outlier values\'\n');
                # for idx, value in values_normal:
                    # file.write('        {0} {1}\n'.format(idx + 1, value))
                # file.write('EOF\n');
                # for idx, value in values_outliers:
                    # file.write('        {0} {1}\n'.format(idx + 1, value))
                # file.write('EOF\n');

            # subprocess.check_call(['gnuplot', filename_base + '.plt'])

# # Baseline diff.
# print 'Generating plot: baseline_abs_diff...'
# baseline_plotstyle_nrs = [plot_style_nr for filename_base, title, plot_style_nr, is_ref_model in experiments if '_baseline_' in filename_base]
# assert len(baseline_plotstyle_nrs) == 2
# baseline_abs_diff_info = dict()
# for csv_records in csvs_records:
    # filename = csv_records[0]['filename']
    # nr = get_plot_style_nr(filename)
    # if nr not in baseline_plotstyle_nrs:
        # continue
    # for r in csv_records:
        # if r['compareResult'] == 'SAME':
            # time = get_total_active_learning_time(r)
            # name = r['name']
            # if name in baseline_abs_diff_info:
                # baseline_abs_diff_info[name].append((nr, time))
            # else:
                # baseline_abs_diff_info[name] = [(nr, time)]
# try:
    # baseline_abs_diffs = []
    # baseline_rel_diffs = []
    # baseline_abs_rel_diffs = []
    # for name, pairs in baseline_abs_diff_info.iteritems():
        # assert len(pairs) == 2
        # pairs = sorted(pairs)
        # assert pairs[0][0] == 1
        # assert pairs[1][0] == 2
        # time1 = pairs[0][1]
        # time2 = pairs[1][1]
        # diff = time1 - time2
        # abs_sec = diff*1.0/1000
        # rel_percentage = diff*1.0/time1*100
        # baseline_abs_diffs.append(abs_sec)
        # baseline_rel_diffs.append(rel_percentage)
        # baseline_abs_rel_diffs.append( (abs_sec, rel_percentage) )
    # baseline_abs_diffs = sorted(baseline_abs_diffs)
    # baseline_rel_diffs = sorted(baseline_rel_diffs)
# finally:
    # pass
# max_baseline_abs_diff = max(baseline_abs_diffs)
# min_baseline_abs_diff = min(baseline_abs_diffs)
# max_baseline_rel_diff = max(baseline_rel_diffs)
# min_baseline_rel_diff = min(baseline_rel_diffs)
# with open('baseline_abs_diff.plt', 'w') as file:
    # file.write('set terminal png size 1000,600\n')
    # file.write('set output "baseline_abs_diff.png"\n')
    # file.write('\n')
    # file.write('set xlabel "Model number (sorted on time difference)"\n')
    # file.write('set ylabel "Difference in active learning (learning+testing) time [s]"\n')
    # file.write('set key off\n')
    # file.write('\n')
    # #file.write('set xtics 40\n')
    # file.write('set xtics add ("{}" {})\n'.format(len(baseline_abs_diffs), len(baseline_abs_diffs)))
    # file.write('set ytics add ("{}" {})\n'.format(round(max_baseline_abs_diff,2), max_baseline_abs_diff))
    # file.write('set ytics add ("{}" {})\n'.format(round(min_baseline_abs_diff,2), min_baseline_abs_diff))
    # #file.write('set ylabel offset 2\n')
    # file.write('\n')
    # file.write('set style line 1 lc rgb \'#32CD32\' linetype 1 linewidth 2\n')
    # file.write('\n')
    # file.write('set style line 11 lc rgb \'#000000\' lt 1\n')
    # file.write('set border 3 back ls 11\n')
    # file.write('set border linewidth 1.5\n')
    # file.write('\n')
    # file.write('set style line 12 lc rgb \'#808080\' lt 0 lw 1\n')
    # file.write('set grid back ls 12\n')
    # file.write('set grid back\n')
    # file.write('\n')
    # file.write('set autoscale yfixmin\n')
    # file.write('set autoscale yfixmax\n')
    # file.write('set autoscale xfixmin\n')
    # file.write('set autoscale xfixmax\n')
    # file.write('set offsets graph 0.05, graph 0.05, graph 0.05, graph 0.05\n')
    # file.write('\n')
    # file.write('plot \'-\' using 1:2 ls 1 notitle \n');
    # for idx, value in enumerate(baseline_abs_diffs):
        # file.write('        {0} {1}\n'.format(idx + 1, value))
    # file.write('EOF\n');
# subprocess.check_call(['gnuplot', 'baseline_abs_diff.plt'])
# print 'Generating plot: baseline_rel_diff...'
# with open('baseline_rel_diff.plt', 'w') as file:
    # file.write('set terminal png size 1000,600\n')
    # file.write('set output "baseline_rel_diff.png"\n')
    # file.write('\n')
    # file.write('set xlabel "Model number (sorted on difference)"\n')
    # file.write('set ylabel "Difference in active learning (learning+testing) time [% of first baseline]"\n')
    # file.write('set key off\n')
    # file.write('\n')
    # file.write('set xtics add ("{}" {})\n'.format(len(baseline_rel_diffs), len(baseline_rel_diffs)))
    # #file.write('set ytics add ("{}" {})\n'.format(round(max_baseline_rel_diff,2), max_baseline_rel_diff))
    # #file.write('set ytics add ("{}" {})\n'.format(round(min_baseline_rel_diff,2), min_baseline_rel_diff))
    # #file.write('set ylabel offset 3\n')
    # file.write('\n')
    # file.write('set style line 1 lc rgb \'#32CD32\' linetype 1 linewidth 2\n')
    # file.write('\n')
    # file.write('set style line 11 lc rgb \'#000000\' lt 1\n')
    # file.write('set border 3 back ls 11\n')
    # file.write('set border linewidth 1.5\n')
    # file.write('\n')
    # file.write('set style line 12 lc rgb \'#808080\' lt 0 lw 1\n')
    # file.write('set grid back ls 12\n')
    # file.write('set grid back\n')
    # file.write('\n')
    # file.write('set autoscale yfixmin\n')
    # file.write('set autoscale yfixmax\n')
    # file.write('set autoscale xfixmin\n')
    # file.write('set autoscale xfixmax\n')
    # file.write('set offsets graph 0.05, graph 0.05, graph 0.05, graph 0.05\n')
    # file.write('\n')
    # file.write('plot \'-\' using 1:2 ls 1 notitle \n');
    # for idx, value in enumerate(baseline_rel_diffs):
        # file.write('        {0} {1}\n'.format(idx + 1, value))
    # file.write('EOF\n');
# subprocess.check_call(['gnuplot', 'baseline_rel_diff.plt'])
# print 'Generating plot: baseline_abs_rel_diff...'
# with open('baseline_abs_rel_diff.plt', 'w') as file:
    # file.write('set terminal png size 1000,600\n')
    # file.write('set output "baseline_abs_rel_diff.png"\n')
    # file.write('\n')
    # file.write('set xlabel "Difference in active learning (learning+testing) time [s]"\n')
    # file.write('set ylabel "Difference in active learning (learning+testing) time [% of first baseline]"\n')
    # file.write('set key off\n')
    # file.write('\n')
    # #file.write('set xtics add ("{}" {})\n'.format(len(baseline_abs_rel_diffs), len(baseline_abs_rel_diffs)))
    # #file.write('set ytics add ("{}" {})\n'.format(round(max_baseline_rel_diff,2), max_baseline_rel_diff))
    # #file.write('set ytics add ("{}" {})\n'.format(round(min_baseline_rel_diff,2), min_baseline_rel_diff))
    # #file.write('set ylabel offset 2\n')
    # file.write('\n')
    # file.write('set style line 1 lc rgb \'#32CD32\' linetype 1 linewidth 2\n')
    # file.write('\n')
    # file.write('set style line 11 lc rgb \'#000000\' lt 1\n')
    # file.write('set border 3 back ls 11\n')
    # file.write('set border linewidth 1.5\n')
    # file.write('\n')
    # file.write('set style line 12 lc rgb \'#808080\' lt 0 lw 1\n')
    # file.write('set grid back ls 12\n')
    # file.write('set grid back\n')
    # file.write('\n')
    # file.write('set autoscale yfixmin\n')
    # file.write('set autoscale yfixmax\n')
    # file.write('set autoscale xfixmin\n')
    # file.write('set autoscale xfixmax\n')
    # file.write('set offsets graph 0.05, graph 0.05, graph 0.05, graph 0.05\n')
    # file.write('\n')
    # file.write('plot \'-\' using 1:2 ls 1 notitle \n');
    # for abs, rel in baseline_abs_rel_diffs:
        # file.write('        {0} {1}\n'.format(abs, rel))
    # file.write('EOF\n');
# subprocess.check_call(['gnuplot', 'baseline_abs_rel_diff.plt'])

# # Baseline: number of states vs test time as percentage of total AL time
# print 'Generating plot: plot_baseline_learn_vs_test_percentage_vs_nr_of_states...'
# baseline_records = [csv_records for csv_records in csvs_records if csv_records[0]['filename'] == '2019-07-07_60m_q1_wp_baseline_pc.csv']
# assert len(baseline_records) == 1
# baseline_records = baseline_records[0]
# max_nr_states = max([int(r['nrExpectedMealyStates']) for r in baseline_records])
# with open('plot_baseline_learn_vs_test_percentage_vs_nr_of_states.plt', 'w') as file:
    # file.write('set terminal png size 900,500\n')
    # file.write('set output "plot_baseline_learn_vs_test_percentage_vs_nr_of_states.png"\n')
    # file.write('\n')
    # file.write('set xlabel "Number of Mealy machine states"\n')
    # file.write('set ylabel "Testing time as percentage of learning + testing time"\n')
    # file.write('set xtics add ("{}" {})\n'.format(max_nr_states, max_nr_states))
    # file.write('set key off\n')
    # file.write('\n')
    # file.write('set style line 1 linecolor rgb \'#32CD32\' linetype 1\n')
    # file.write('\n')
    # file.write('set style line 11 lc rgb \'#000000\' lt 1\n')
    # file.write('set border 3 back ls 11\n')
    # file.write('set border linewidth 1.5\n')
    # file.write('\n')
    # file.write('set style line 12 lc rgb \'#808080\' lt 0 lw 1\n')
    # file.write('set grid back ls 12\n')
    # file.write('set grid back\n')
    # file.write('\n')
    # file.write('set autoscale yfixmin\n')
    # file.write('set autoscale yfixmax\n')
    # file.write('set autoscale xfixmin\n')
    # file.write('set autoscale xfixmax\n')
    # file.write('set offsets graph 0.05, graph 0.05, graph 0.05, graph 0.05\n')
    # file.write('set logscale x 10\n')
    # #file.write('set logscale y 10\n')
    # file.write('\n')
    # file.write('plot \'-\' using 1:2 ls 1 title "Component learned (no timeout)\n');
    # for r in baseline_records:
        # if r['compareResult'] != 'SAME':
            # continue
        # assert r['learnedResultUsedModel'] == 'learning_result' # same, no timeout
        # nr_of_states = int(r['nrExpectedMealyStates'])
        # percentage = int(r['durationMsLearningTest']) * 1.0 / (int(r['durationMsLearningLearn'])+int(r['durationMsLearningTest'])) * 100
        # file.write('        {0} {1}\n'.format(nr_of_states, percentage))
    # file.write('EOF\n');

# subprocess.check_call(['gnuplot', 'plot_baseline_learn_vs_test_percentage_vs_nr_of_states.plt'])

# Done.
print 'Done!'
